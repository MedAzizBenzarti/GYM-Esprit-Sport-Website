<?php
include "../../entity/evenement.php";
include "../../controller/evenementC.php";

if (isset($_POST['id']) ){

    $eventC = new  evenementC();
    $event = new evenement($_POST['id'],$_POST['titre'],$_POST['date'],$_POST['lieu'],$_POST['descrip'],$_POST['dateModif'],$_POST['dateAjout'],$_POST['nbPartic'],$_POST['etat']
    );

    $eventC->ajouter($event);
    header('Location: listeEvent.php');
    //var_dump($event);

}


?>