<?PHP
require_once "config.php";


class evenementC
{
    function ajouter($evenement)
    {
        $sql = "insert into evenement (titre,date,lieu,descrip,dateModif,dateAjout,nbPartic,etat,idtype) values (:titre,:date,:lieu,:descrip,:dateModif,:dateAjout,:nbPartic,:etat, :idtype)";
        $db = config::getConnexion();
        try {
            $req = $db->prepare($sql);
            //$req->bindValue(':id', $evenement->getid());
            $req->bindValue(':titre', $evenement->gettitre());
            $req->bindValue(':descrip', $evenement->getdescrip());
            $req->bindValue(':date', $evenement->getdate());
            $req->bindValue(':lieu', $evenement->getlieu());
            $req->bindValue(':dateModif', $evenement->getdateModif());
            $req->bindValue(':dateAjout', $evenement->getdateAjout());
            $req->bindValue(':nbPartic', $evenement->getnbPartic());
            $req->bindValue(':etat', $evenement->getetat());
            $req->bindValue(':idtype', $evenement->getidtype());

            $req->execute();

        } catch (Exception $e) {
            echo 'Erreur: ' . $e->getMessage();
        }
    }

    function afficher()
    {
        $sql = "SELECT * from evenement";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }

    function afficherT()
    {
        $sql = "SELECT a.*,b.nom  from evenement a inner join type  b on a.idtype = b.id";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }

    function supprimer($id)
    {
        $sql = "DELETE FROM evenement WHERE id= :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }
    function recuperer($id){
        $sql="SELECT * from evenement where id=$id";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifier($evenement, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE evenement SET 
						titre = :titre, 
	
						date = :date,
						lieu= :lieu,
						descrip = :description,
						dateModif = :dateModif,
						dateAjout=:dateAjout,
						nbPartic = :nbPartic,
						idtype= :idtype,
						etat= :etat
			
					WHERE id = :id'
            );

            $query->execute([
                'titre'=>$evenement->gettitre(),
                'date'=>$evenement->getdate(),
                'lieu'=>$evenement->getlieu(),
                'descrip'=>$evenement->getdescrip(),
                'dateModif'=>$evenement->getdateModif(),
                'dateAjout'=>$evenement->getdateAjout(),
                'nbPartic'=>$evenement->getnbPartic(),
                'etat'=>$evenement->getetat(),
                'idtype'=>$evenement->getidtype(),
                'id'=>$id
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }


}
?>